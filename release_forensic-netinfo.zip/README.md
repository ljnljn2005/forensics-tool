# forensic-netinfo

一个简单的 Rust 命令行取证工具，用于从映射的 Linux 文件系统提取网络配置信息。


图形界面用法：

1. 编译：

```bash
cargo build --release
```

2. 运行（Windows 上双击可执行文件或从命令行启动）：

```bash
./target/release/forensic-netinfo.exe
```

3. 在窗口中输入映射根路径（例如 C:\\hlnet\\...\\分区0），点击“提取网络信息”，结果将以 JSON 显示在下方。

该工具会尝试读取并输出（JSON 格式）：
- `/etc/hostname`
- `/etc/hosts`
- `/etc/resolv.conf`
- `/etc/network/interfaces`
- `/etc/netplan/*.yaml`（解析为 JSON）
- `/etc/NetworkManager/system-connections/*`

如果需要，我可以继续：
- 添加更完整的解析（解析 system-connections 的 keyfile、提取 IP 和网关等）
- 添加单元测试并在本地构建运行
